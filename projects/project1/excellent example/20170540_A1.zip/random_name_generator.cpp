#include <iostream>
#include <fstream>
#include <string>
#include <time.h>

using namespace std;

int main()
{
    srand(time(NULL));
    std::string tmpName;
    //Open the files
    std::ifstream nameList("last-names.txt");
    ofstream studentList;
    studentList.open ("StudentGenerator.txt");

    studentList << "\"sid\";\"sname\";\"sex\";\"age\";\"syear\";\"gpa\"\n";

    for(int sid = 105; sid<5000; sid++)
    {

        studentList << sid     << ";\"";   //sid
        std::getline(nameList, tmpName);
        studentList << tmpName << "\";\""; //sname

        if(rand()%2) //sex
            studentList << "f\";";
        else
            studentList << "m\";";

        studentList << rand()%10 + 18   << ";";  //age
        studentList << rand()%6  + 1    << ";";  //syear
        studentList << rand()%4  << ","
                    << rand()%10 << 0   << "\n"; //gpa
    }

    studentList.close();
    return 0;
}
